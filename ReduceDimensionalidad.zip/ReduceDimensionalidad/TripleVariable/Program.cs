﻿/* Universidad Libre - Cali
 * Facultad de Ingeniería
 * Investigación
 * Proyecto: ECOSISTEMA DE ARQUITECTURAS DIGITALES PARA SOLUCIONES BASADAS EN INTELIGENCIA ARTIFICIAL
 * Fecha: Junio de 2025
 * Autor: Rafael Alberto Moreno Parra
 * Correo: rafael-morenop@unilibre.edu.co
 * 
 * Artículo:
 * Reducción de Dimensionalidad vs. Modelo Completo: Algoritmos Genéticos en la Identificación de Patrones
 * 
 * Resumen
 * Este estudio compara dos enfoques basados en algoritmos genéticos para la detección de patrones en conjuntos
 * de datos con variables causales (X, Y) y una variable dependiente (Z). El primer enfoque reduce la
 * dimensionalidad mediante la construcción de una nueva variable Q = 10X + Y, mientras que el segundo trabaja
 * directamente con las variables originales. Se evalúa el desempeño de ambos métodos en comparación con una
 * red neuronal de tipo perceptrón multicapa, analizando la precisión y capacidad de generalización. Los resultados
 * ofrecen perspectivas sobre la efectividad de la reducción de dimensionalidad frente a la complejidad del
 * modelo completo en la búsqueda de patrones.
 * 
 * Abstract
 * This study presents a comparative analysis of two genetic algorithm-based approaches for pattern detection
 * in datasets with causal variables (X, Y) and a dependent variable (Z). The first method reduces dimensionality
 * by constructing a new variable Q = 10X + Y, while the second approach operates directly on the original variables.
 * The performance of both methods is assessed against a multilayer perceptron neural network, examining accuracy
 * and generalization capability. The findings provide insights into the trade-off between dimensionality reduction
 * and model complexity in pattern discovery tasks.
 * 
 * Conclusiones
 * Los resultados de este estudio evidencian la importancia de preservar la dimensionalidad original en la identificación
 * de patrones mediante algoritmos genéticos y redes neuronales. La estrategia de reducción dimensional, basada en la
 * construcción de una nueva variable (Q = 10X + Y), mostró un ajuste deficiente en comparación con el enfoque que utilizó
 * directamente las variables originales (X, Y, Z). En contraste, el algoritmo genético aplicado sobre las tres variables
 * logró una mejor capacidad de modelado y ajuste, resaltando la relevancia de mantener la información completa en el proceso
 * evolutivo de búsqueda de patrones.
 * Sin embargo, el desempeño del perceptrón multicapa superó significativamente ambas estrategias basadas en algoritmos
 * genéticos, logrando una mejor precisión y capacidad de generalización. Este hallazgo sugiere que, para problemas de
 * identificación de patrones complejos, las redes neuronales pueden ofrecer ventajas superiores en términos de ajuste
 * y robustez frente a enfoques evolutivos.
 * Estos resultados abren la posibilidad de investigar combinaciones híbridas entre algoritmos genéticos y redes neuronales,
 * con el objetivo de potenciar las capacidades de aprendizaje automático en la detección de estructuras ocultas en los datos.
 * Además, futuras investigaciones podrían explorar otros métodos de reducción de dimensionalidad que preserven mejor la 
 * información relevante sin comprometer el ajuste del modelo.
 * */

using System.Text;

namespace TripleVariable {
    internal class Program {
        static Ecuacion Datos = new();
        static Perceptron perceptron;

        static void Main(string[] args) {
            Console.OutputEncoding = Encoding.UTF8;

            //Único generador de valores aleatorios
            Random Azar = new();

            int TotalPruebas = 100;
            for (int Cont = 1; Cont <=  TotalPruebas; Cont++)
                Pruebas(Azar);
        }

        static void Mensaje(bool Mostrar, string Texto) {
            if (Mostrar == false) return;
            Console.WriteLine(Texto);
        }

        static void Pruebas(Random Azar) {
            bool Mensajes = false;

            //Genera datos de una ecuación creada al azar
            Mensaje(Mensajes, "1. Genera datos de una ecuacíón creada al azar");
            GeneraDatos(Azar);

            //Genera las diferentes poblaciones tipo A
            Mensaje(Mensajes, "2. Genera las diferentes poblaciones tipo A (convierte XYZ a QZ)");
            int NumPoblaciones = 10;
            List<PoblacionA> poblacionA = [];

            poblacionA.Clear();
            int NumIndividuosPorPoblacion = 50;
            for (int Cont = 0; Cont < NumPoblaciones; Cont++) {
                poblacionA.Add(new PoblacionA(Azar, NumIndividuosPorPoblacion));
            }

            //Entrena cada población
            Mensaje(Mensajes, "3. Entrena cada población tipo A");
            int NumCiclosMejoraGenetico = 4000;
            for (int Cont = 0; Cont < poblacionA.Count; Cont++)
                poblacionA[Cont].Entrenar(Azar, Datos, NumCiclosMejoraGenetico);

            //Toma el mejor individuo de cada población y lo compara con los valores test
            Mensaje(Mensajes, "4. Evalua cada población tipo A");
            for (int Cont = 0; Cont < poblacionA.Count; Cont++)
                poblacionA[Cont].EvaluarTest(Datos);

            //Muestra el individuo con mejor ajuste
            Mensaje(Mensajes, "5. Muestra el individuo con mejor ajuste en los datos test");
            int MejorPoblacionA = -1;
            int MejorIndividuoA = -1;
            double MejorAjusteTestA = double.MaxValue;
            for (int Cont = 0; Cont < poblacionA.Count; Cont++) {
                for (int Indiv = 0; Indiv < poblacionA[Cont].individuos.Count; Indiv++) {
                    if (poblacionA[Cont].individuos[Indiv].Ajuste < MejorAjusteTestA) {
                        MejorPoblacionA = Cont;
                        MejorIndividuoA = Indiv;
                        MejorAjusteTestA = poblacionA[Cont].individuos[Indiv].Ajuste;
                    }
                }
            }

            Mensaje(Mensajes, "Población Tipo A");
            Mensaje(Mensajes, "Mejor Población: " + MejorPoblacionA);
            Mensaje(Mensajes, "Mejor Individuo: " + MejorIndividuoA);
            Mensaje(Mensajes, "Mejor Ajuste: " + MejorAjusteTestA);

            //Genera las diferentes poblaciones tipo B
            Mensaje(Mensajes, "\r\n6. Genera las diferentes poblaciones tipo B (mantiene XYZ)");
            List<PoblacionB> poblacionB = [];

            poblacionB.Clear();
            for (int Cont = 0; Cont < NumPoblaciones; Cont++) {
                poblacionB.Add(new PoblacionB(Azar, NumIndividuosPorPoblacion));
            }

            //Evalúa cada población
            Mensaje(Mensajes, "7. Entrena cada población tipo B");
            for (int Cont = 0; Cont < poblacionB.Count; Cont++)
                poblacionB[Cont].Entrenar(Azar, Datos, NumCiclosMejoraGenetico);

            //Toma el mejor individuo de cada población y lo compara con los valores test
            Mensaje(Mensajes, "8. Evalúa cada población tipo B");
            for (int Cont = 0; Cont < poblacionB.Count; Cont++)
                poblacionB[Cont].EvaluarTest(Datos);

            //Muestra el individuo con mejor ajuste
            Mensaje(Mensajes, "9. Muestra el individuo con mejor ajuste");
            int MejorPoblacionB = -1;
            int MejorIndividuoB = -1;
            double MejorAjusteTestB = double.MaxValue;
            for (int Cont = 0; Cont < poblacionA.Count; Cont++) {
                for (int Indiv = 0; Indiv < poblacionB[Cont].individuos.Count; Indiv++) {
                    if (poblacionB[Cont].individuos[Indiv].Ajuste < MejorAjusteTestB) {
                        MejorPoblacionB = Cont;
                        MejorIndividuoB = Indiv;
                        MejorAjusteTestB = poblacionB[Cont].individuos[Indiv].Ajuste;
                    }
                }
            }

            Mensaje(Mensajes, "Población Tipo B");
            Mensaje(Mensajes, "Mejor Población: " + MejorPoblacionB);
            Mensaje(Mensajes, "Mejor Individuo: " + MejorIndividuoB);
            Mensaje(Mensajes, "Mejor Ajuste: " + MejorAjusteTestB);

            //El perceptrón multicapa
            Mensaje(Mensajes, "\r\n10. Red Neuronal");
            int CiclosNeuronal = 1000;
            int capa0 = 5;
            int capa1 = 5;
            RedNeuronal(Azar, Datos, CiclosNeuronal, capa0, capa1);

            //Muestra para poner en Excel
            //A. Imprimir la tabla de datos
            Mensaje(Mensajes, "\r\nDatos de entrenamiento");
            Mensaje(Mensajes, "X;Y;2D;Z;TipoA;Diferencia;TipoB;Diferencia;Neuronal;Diferencia");
            double AcumulaTipoA = 0;
            double AcumulaTipoB = 0;
            double AcumulaNeuronal = 0;
            for (int Cont = 0; Cont < Datos.Registros.Count; Cont++) {

                //El algoritmo de población Tipo A
                double X = Datos.Registros[Cont].ValorX;
                double Y = Datos.Registros[Cont].ValorY;
                double XY = Datos.Registros[Cont].Valor2D;
                double Z = Datos.Registros[Cont].ValorZ;
                double TipoA = poblacionA[MejorPoblacionA].individuos[MejorIndividuoA].Valor(XY);
                double DifTipoA = (Z - TipoA) * (Z - TipoA);
                AcumulaTipoA += DifTipoA;

                //El algoritmo de población Tipo B
                double TipoB = poblacionB[MejorPoblacionB].individuos[MejorIndividuoB].Valor(X, Y);
                double DifTipoB = (Z - TipoB) * (Z - TipoB);
                AcumulaTipoB += DifTipoB;

                //La red neuronal
                List<double> entradas = [X, Y];
                List<double> salidaEsperada = [Z];
                perceptron.calculaSalida(entradas);
                double Neuronal = perceptron.capas[2].salidas[0];
                double DifNeuronal = (Z - Neuronal) * (Z - Neuronal);
                AcumulaNeuronal += DifNeuronal;

                Mensaje(Mensajes, X + ";" + Y + ";" + XY + ";" + Z + ";" + TipoA + ";" + DifTipoA + ";" + TipoB + ";" + DifTipoB + ";" + Neuronal + ";" + DifNeuronal);
            }
            Mensaje(Mensajes, "Total Diferencia;" + AcumulaTipoA + ";" + AcumulaTipoB + ";" + AcumulaNeuronal);

            Mensaje(Mensajes, "\r\nDatos test");
            Mensaje(Mensajes, "X;Y;2D;Z;TipoA;Diferencia;TipoB;Diferencia;Neuronal;Diferencia");
            AcumulaTipoA = 0;
            AcumulaTipoB = 0;
            AcumulaNeuronal = 0;
            for (int Cont = 0; Cont < Datos.Test.Count; Cont++) {

                //El algoritmo de población Tipo A
                double X = Datos.Test[Cont].ValorX;
                double Y = Datos.Test[Cont].ValorY;
                double XY = Datos.Test[Cont].Valor2D;
                double Z = Datos.Test[Cont].ValorZ;
                double TipoA = poblacionA[MejorPoblacionA].individuos[MejorIndividuoA].Valor(XY);
                double DifTipoA = (Z - TipoA) * (Z - TipoA);
                AcumulaTipoA += DifTipoA;

                //El algoritmo de población Tipo B
                double TipoB = poblacionB[MejorPoblacionB].individuos[MejorIndividuoB].Valor(X, Y);
                double DifTipoB = (Z - TipoB) * (Z - TipoB);
                AcumulaTipoB += DifTipoB;

                //La red neuronal
                List<double> entradas = [X, Y];
                List<double> salidaEsperada = [Z];
                perceptron.calculaSalida(entradas);
                double Neuronal = perceptron.capas[2].salidas[0];
                double DifNeuronal = (Z - Neuronal) * (Z - Neuronal);
                AcumulaNeuronal += DifNeuronal;

                Mensaje(Mensajes, X + ";" + Y + ";" + XY + ";" + Z + ";" + TipoA + ";" + DifTipoA + ";" + TipoB + ";" + DifTipoB + ";" + Neuronal + ";" + DifNeuronal);
            }
            Console.WriteLine("Total Diferencia;" + AcumulaTipoA + ";" + AcumulaTipoB + ";" + AcumulaNeuronal);
        }

        static void GeneraDatos(Random Azar) {
            //Profundidad del árbol binario
            int Profundidad = 8;

            //Cuantos registros va a crear
            int NumRegistros = 500;

            //Genera los datos
            Datos.CreaDatos(Azar, Profundidad, NumRegistros);
        }

        //La red neuronal
        static void RedNeuronal(Random azar, Ecuacion Datos, int CiclosNeuronal, int capa0, int capa1) {

            int numEntradas = 2; //Número de entradas
            int capa2 = 1; //Total neuronas en la capa 2
            perceptron = new Perceptron(azar, numEntradas, capa0, capa1, capa2);

            //Estas serán las entradas externas al perceptrón
            List<double> entradas = [0, 0];

            //Estas serán las salidas esperadas externas al perceptrón
            List<double> salidaEsperada = [0];

            //Ciclo que entrena la red neuronal
            for (int Ciclo = 1; Ciclo < CiclosNeuronal; Ciclo++) {

                //Por cada ciclo, se entrena el perceptrón con todos los valores
                for (int Cont = 0; Cont < Datos.Registros.Count; Cont++) {
                    //Entradas y salidas esperadas
                    entradas[0] = Datos.Registros[Cont].ValorX;
                    entradas[1] = Datos.Registros[Cont].ValorY;
                    salidaEsperada[0] = Datos.Registros[Cont].ValorZ;

                    //Primero calcula la salida del perceptrón con esas entradas
                    perceptron.calculaSalida(entradas);

                    //Luego entrena el perceptrón para ajustar los pesos y umbrales
                    perceptron.Entrena(entradas, salidaEsperada);
                }
            }
        }
    }
}
