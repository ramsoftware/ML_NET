﻿/* Universidad Libre - Cali
 * Facultad de Ingeniería
 * Investigación
 * Proyecto: ECOSISTEMA DE ARQUITECTURAS DIGITALES PARA SOLUCIONES BASADAS EN INTELIGENCIA ARTIFICIAL
 * Fecha: Junio de 2025
 * Autor: Rafael Alberto Moreno Parra
 * Correo: rafael-morenop@unilibre.edu.co
 * 
 * Artículo:
 * Reducción de Dimensionalidad vs. Modelo Completo: Algoritmos Genéticos en la Identificación de Patrones
 * 
 * Resumen
 * Este estudio compara dos enfoques basados en algoritmos genéticos para la detección de patrones en conjuntos
 * de datos con variables causales (X, Y) y una variable dependiente (Z). El primer enfoque reduce la
 * dimensionalidad mediante la construcción de una nueva variable Q = 10X + Y, mientras que el segundo trabaja
 * directamente con las variables originales. Se evalúa el desempeño de ambos métodos en comparación con una
 * red neuronal de tipo perceptrón multicapa, analizando la precisión y capacidad de generalización. Los resultados
 * ofrecen perspectivas sobre la efectividad de la reducción de dimensionalidad frente a la complejidad del
 * modelo completo en la búsqueda de patrones.
 * 
 * Abstract
 * This study presents a comparative analysis of two genetic algorithm-based approaches for pattern detection
 * in datasets with causal variables (X, Y) and a dependent variable (Z). The first method reduces dimensionality
 * by constructing a new variable Q = 10X + Y, while the second approach operates directly on the original variables.
 * The performance of both methods is assessed against a multilayer perceptron neural network, examining accuracy
 * and generalization capability. The findings provide insights into the trade-off between dimensionality reduction
 * and model complexity in pattern discovery tasks.
 * 
 * Conclusiones
 * Los resultados de este estudio evidencian la importancia de preservar la dimensionalidad original en la identificación
 * de patrones mediante algoritmos genéticos y redes neuronales. La estrategia de reducción dimensional, basada en la
 * construcción de una nueva variable (Q = 10X + Y), mostró un ajuste deficiente en comparación con el enfoque que utilizó
 * directamente las variables originales (X, Y, Z). En contraste, el algoritmo genético aplicado sobre las tres variables
 * logró una mejor capacidad de modelado y ajuste, resaltando la relevancia de mantener la información completa en el proceso
 * evolutivo de búsqueda de patrones.
 * Sin embargo, el desempeño del perceptrón multicapa superó significativamente ambas estrategias basadas en algoritmos
 * genéticos, logrando una mejor precisión y capacidad de generalización. Este hallazgo sugiere que, para problemas de
 * identificación de patrones complejos, las redes neuronales pueden ofrecer ventajas superiores en términos de ajuste
 * y robustez frente a enfoques evolutivos.
 * Estos resultados abren la posibilidad de investigar combinaciones híbridas entre algoritmos genéticos y redes neuronales,
 * con el objetivo de potenciar las capacidades de aprendizaje automático en la detección de estructuras ocultas en los datos.
 * Además, futuras investigaciones podrían explorar otros métodos de reducción de dimensionalidad que preserven mejor la 
 * información relevante sin comprometer el ajuste del modelo.
 * */

namespace TripleVariable {
    internal abstract class Individuo {
        //Coeficientes del individuo
        public double[] Coef;
        
        //Mantiene el valor original de un coeficiente cuando se muta
        //En caso de que la mutación no sirva se restaura el valor
        //original
        private int PosOriginal;
        private double ValorOriginal;

        //Ajuste del individuo
        public double Ajuste;

        //Muta el individuo
        public void Muta(Random Azar) {
            PosOriginal = Azar.Next(Coef.Length);
            ValorOriginal = Coef[PosOriginal];
            Coef[PosOriginal] += (2 * Azar.NextDouble() - 1);
        }

        //Restaura valor original del coeficiente
        public void Restaura() {
            Coef[PosOriginal] = ValorOriginal;
        }
    }
}
