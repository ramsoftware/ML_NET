﻿/* Universidad Libre - Cali
 * Facultad de Ingeniería
 * Investigación
 * Proyecto: ECOSISTEMA DE ARQUITECTURAS DIGITALES PARA SOLUCIONES BASADAS EN INTELIGENCIA ARTIFICIAL
 * Fecha: Junio de 2025
 * Autor: Rafael Alberto Moreno Parra
 * Correo: rafael-morenop@unilibre.edu.co
 * 
 * Artículo:
 * Reducción de Dimensionalidad vs. Modelo Completo: Algoritmos Genéticos en la Identificación de Patrones
 * 
 * Resumen
 * Este estudio compara dos enfoques basados en algoritmos genéticos para la detección de patrones en conjuntos
 * de datos con variables causales (X, Y) y una variable dependiente (Z). El primer enfoque reduce la
 * dimensionalidad mediante la construcción de una nueva variable Q = 10X + Y, mientras que el segundo trabaja
 * directamente con las variables originales. Se evalúa el desempeño de ambos métodos en comparación con una
 * red neuronal de tipo perceptrón multicapa, analizando la precisión y capacidad de generalización. Los resultados
 * ofrecen perspectivas sobre la efectividad de la reducción de dimensionalidad frente a la complejidad del
 * modelo completo en la búsqueda de patrones.
 * 
 * Abstract
 * This study presents a comparative analysis of two genetic algorithm-based approaches for pattern detection
 * in datasets with causal variables (X, Y) and a dependent variable (Z). The first method reduces dimensionality
 * by constructing a new variable Q = 10X + Y, while the second approach operates directly on the original variables.
 * The performance of both methods is assessed against a multilayer perceptron neural network, examining accuracy
 * and generalization capability. The findings provide insights into the trade-off between dimensionality reduction
 * and model complexity in pattern discovery tasks.
 * 
 * Conclusiones
 * Los resultados de este estudio evidencian la importancia de preservar la dimensionalidad original en la identificación
 * de patrones mediante algoritmos genéticos y redes neuronales. La estrategia de reducción dimensional, basada en la
 * construcción de una nueva variable (Q = 10X + Y), mostró un ajuste deficiente en comparación con el enfoque que utilizó
 * directamente las variables originales (X, Y, Z). En contraste, el algoritmo genético aplicado sobre las tres variables
 * logró una mejor capacidad de modelado y ajuste, resaltando la relevancia de mantener la información completa en el proceso
 * evolutivo de búsqueda de patrones.
 * Sin embargo, el desempeño del perceptrón multicapa superó significativamente ambas estrategias basadas en algoritmos
 * genéticos, logrando una mejor precisión y capacidad de generalización. Este hallazgo sugiere que, para problemas de
 * identificación de patrones complejos, las redes neuronales pueden ofrecer ventajas superiores en términos de ajuste
 * y robustez frente a enfoques evolutivos.
 * Estos resultados abren la posibilidad de investigar combinaciones híbridas entre algoritmos genéticos y redes neuronales,
 * con el objetivo de potenciar las capacidades de aprendizaje automático en la detección de estructuras ocultas en los datos.
 * Además, futuras investigaciones podrían explorar otros métodos de reducción de dimensionalidad que preserven mejor la 
 * información relevante sin comprometer el ajuste del modelo.
 * */
namespace TripleVariable {
    internal class Neurona {
        public List<double> pesos; //Los pesos para cada entrada
        public List<double> nuevospesos; //Nuevos pesos dados por el algoritmo de "backpropagation"
        public double umbral; //El peso del umbral
        public double nuevoumbral; //Nuevo umbral dado por el algoritmo de "backpropagation"

        //Inicializa los pesos y umbral con un valor al azar
        public Neurona(Random azar, int totalEntradas) {
            pesos = new List<double>();
            nuevospesos = new List<double>();
            for (int cont = 0; cont < totalEntradas; cont++) {
                pesos.Add(azar.NextDouble());
                nuevospesos.Add(0);
            }
            umbral = azar.NextDouble();
            nuevoumbral = 0;
        }

        //Calcula la salida de la neurona dependiendo de las entradas
        public double calculaSalida(List<double> entradas) {
            double valor = 0;
            for (int cont = 0; cont < pesos.Count; cont++) {
                valor += entradas[cont] * pesos[cont];
            }
            valor += umbral;
            return 1 / (1 + Math.Exp(-valor));
        }

        //Reemplaza viejos pesos por nuevos
        public void actualiza() {
            for (int cont = 0; cont < pesos.Count; cont++) {
                pesos[cont] = nuevospesos[cont];
            }
            umbral = nuevoumbral;
        }
    }
}
