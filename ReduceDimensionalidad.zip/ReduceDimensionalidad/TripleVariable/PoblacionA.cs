﻿/* Universidad Libre - Cali
 * Facultad de Ingeniería
 * Investigación
 * Proyecto: ECOSISTEMA DE ARQUITECTURAS DIGITALES PARA SOLUCIONES BASADAS EN INTELIGENCIA ARTIFICIAL
 * Fecha: Junio de 2025
 * Autor: Rafael Alberto Moreno Parra
 * Correo: rafael-morenop@unilibre.edu.co
 * 
 * Artículo:
 * Reducción de Dimensionalidad vs. Modelo Completo: Algoritmos Genéticos en la Identificación de Patrones
 * 
 * Resumen
 * Este estudio compara dos enfoques basados en algoritmos genéticos para la detección de patrones en conjuntos
 * de datos con variables causales (X, Y) y una variable dependiente (Z). El primer enfoque reduce la
 * dimensionalidad mediante la construcción de una nueva variable Q = 10X + Y, mientras que el segundo trabaja
 * directamente con las variables originales. Se evalúa el desempeño de ambos métodos en comparación con una
 * red neuronal de tipo perceptrón multicapa, analizando la precisión y capacidad de generalización. Los resultados
 * ofrecen perspectivas sobre la efectividad de la reducción de dimensionalidad frente a la complejidad del
 * modelo completo en la búsqueda de patrones.
 * 
 * Abstract
 * This study presents a comparative analysis of two genetic algorithm-based approaches for pattern detection
 * in datasets with causal variables (X, Y) and a dependent variable (Z). The first method reduces dimensionality
 * by constructing a new variable Q = 10X + Y, while the second approach operates directly on the original variables.
 * The performance of both methods is assessed against a multilayer perceptron neural network, examining accuracy
 * and generalization capability. The findings provide insights into the trade-off between dimensionality reduction
 * and model complexity in pattern discovery tasks.
 * 
 * Conclusiones
 * Los resultados de este estudio evidencian la importancia de preservar la dimensionalidad original en la identificación
 * de patrones mediante algoritmos genéticos y redes neuronales. La estrategia de reducción dimensional, basada en la
 * construcción de una nueva variable (Q = 10X + Y), mostró un ajuste deficiente en comparación con el enfoque que utilizó
 * directamente las variables originales (X, Y, Z). En contraste, el algoritmo genético aplicado sobre las tres variables
 * logró una mejor capacidad de modelado y ajuste, resaltando la relevancia de mantener la información completa en el proceso
 * evolutivo de búsqueda de patrones.
 * Sin embargo, el desempeño del perceptrón multicapa superó significativamente ambas estrategias basadas en algoritmos
 * genéticos, logrando una mejor precisión y capacidad de generalización. Este hallazgo sugiere que, para problemas de
 * identificación de patrones complejos, las redes neuronales pueden ofrecer ventajas superiores en términos de ajuste
 * y robustez frente a enfoques evolutivos.
 * Estos resultados abren la posibilidad de investigar combinaciones híbridas entre algoritmos genéticos y redes neuronales,
 * con el objetivo de potenciar las capacidades de aprendizaje automático en la detección de estructuras ocultas en los datos.
 * Además, futuras investigaciones podrían explorar otros métodos de reducción de dimensionalidad que preserven mejor la 
 * información relevante sin comprometer el ajuste del modelo.
 * */
namespace TripleVariable {
    internal class PoblacionA {
        public List<IndividuoA> individuos;
        private int NumPartes;

        public PoblacionA(Random Azar, int TotalIndividuos) {
            individuos = [];

            //Cuantas partes va a tener cada individuo
            NumPartes = Azar.Next(4, 10);

            //Inicializa los individuos
            individuos.Clear();
            for (int Cont = 0; Cont < TotalIndividuos; Cont++)
                individuos.Add(new IndividuoA(Azar, NumPartes));
        }

        public void Entrenar(Random Azar, Ecuacion Datos, int NumeroCiclos) {
            //Evalúa y muta cada individuo en pos de buscar el mejor ajuste
            for(int Ciclo = 1; Ciclo <= NumeroCiclos; Ciclo++) {
                for (int Cont = 0; Cont < individuos.Count; Cont++) {
                    individuos[Cont].Muta(Azar);
                    individuos[Cont].Evalua(Datos);
                }
            }

            //Algoritmo genético clásico:
            //1. Selecciona dos al azar
            //2. Escoge el mejor
            //3. Elimina al peor
            //4. Clona el mejor
            //5. Muta el clon
            //6. Evalúa el clon
            for (int Ciclo = 1; Ciclo <= NumeroCiclos; Ciclo++) {
                
                //1. Selecciona dos al azar
                int IndivA = Azar.Next(individuos.Count);
                int IndivB = 0;
                do {
                    IndivB = Azar.Next(individuos.Count);
                }while (IndivA == IndivB);

                //2. Escoge al mejor
                if (individuos[IndivA].Ajuste < individuos[IndivB].Ajuste) {
                    
                    //3. Elimina al peor y 4. Clona al mejor
                    for (int Copia = 0; Copia < individuos[IndivA].Coef.Length; Copia++)
                        individuos[IndivB].Coef[Copia] = individuos[IndivA].Coef[Copia];
                    
                    //5. Muta el clon
                    individuos[IndivB].Muta(Azar);

                    //6. Evalúa el clon
                    individuos[IndivB].Ajuste = double.MaxValue;
                    individuos[IndivB].Evalua(Datos);
                }
                else if (individuos[IndivB].Ajuste < individuos[IndivA].Ajuste) {

                    //3. Elimina al peor y 4. Clona al mejor
                    for (int Copia = 0; Copia < individuos[IndivB].Coef.Length; Copia++)
                        individuos[IndivA].Coef[Copia] = individuos[IndivB].Coef[Copia];

                    //5. Muta el clon
                    individuos[IndivA].Muta(Azar);

                    //6. Evalúa el clon
                    individuos[IndivA].Ajuste = double.MaxValue;
                    individuos[IndivA].Evalua(Datos);
                }
            }
        }

        public void EvaluarTest(Ecuacion Datos) {
            for (int Cont = 0; Cont < individuos.Count; Cont++) {
                individuos[Cont].Ajuste = double.MaxValue;
                individuos[Cont].EvaluaTest(Datos);
            }
        }
    }
}
