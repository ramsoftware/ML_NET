﻿/* Universidad Libre - Cali
 * Facultad de Ingeniería
 * Investigación
 * Proyecto: ECOSISTEMA DE ARQUITECTURAS DIGITALES PARA SOLUCIONES BASADAS EN INTELIGENCIA ARTIFICIAL
 * Fecha: Junio de 2025
 * Autor: Rafael Alberto Moreno Parra
 * Correo: rafael-morenop@unilibre.edu.co
 * 
 * Artículo:
 * Reducción de Dimensionalidad vs. Modelo Completo: Algoritmos Genéticos en la Identificación de Patrones
 * 
 * Resumen
 * Este estudio compara dos enfoques basados en algoritmos genéticos para la detección de patrones en conjuntos
 * de datos con variables causales (X, Y) y una variable dependiente (Z). El primer enfoque reduce la
 * dimensionalidad mediante la construcción de una nueva variable Q = 10X + Y, mientras que el segundo trabaja
 * directamente con las variables originales. Se evalúa el desempeño de ambos métodos en comparación con una
 * red neuronal de tipo perceptrón multicapa, analizando la precisión y capacidad de generalización. Los resultados
 * ofrecen perspectivas sobre la efectividad de la reducción de dimensionalidad frente a la complejidad del
 * modelo completo en la búsqueda de patrones.
 * 
 * Abstract
 * This study presents a comparative analysis of two genetic algorithm-based approaches for pattern detection
 * in datasets with causal variables (X, Y) and a dependent variable (Z). The first method reduces dimensionality
 * by constructing a new variable Q = 10X + Y, while the second approach operates directly on the original variables.
 * The performance of both methods is assessed against a multilayer perceptron neural network, examining accuracy
 * and generalization capability. The findings provide insights into the trade-off between dimensionality reduction
 * and model complexity in pattern discovery tasks.
 * 
 * Conclusiones
 * Los resultados de este estudio evidencian la importancia de preservar la dimensionalidad original en la identificación
 * de patrones mediante algoritmos genéticos y redes neuronales. La estrategia de reducción dimensional, basada en la
 * construcción de una nueva variable (Q = 10X + Y), mostró un ajuste deficiente en comparación con el enfoque que utilizó
 * directamente las variables originales (X, Y, Z). En contraste, el algoritmo genético aplicado sobre las tres variables
 * logró una mejor capacidad de modelado y ajuste, resaltando la relevancia de mantener la información completa en el proceso
 * evolutivo de búsqueda de patrones.
 * Sin embargo, el desempeño del perceptrón multicapa superó significativamente ambas estrategias basadas en algoritmos
 * genéticos, logrando una mejor precisión y capacidad de generalización. Este hallazgo sugiere que, para problemas de
 * identificación de patrones complejos, las redes neuronales pueden ofrecer ventajas superiores en términos de ajuste
 * y robustez frente a enfoques evolutivos.
 * Estos resultados abren la posibilidad de investigar combinaciones híbridas entre algoritmos genéticos y redes neuronales,
 * con el objetivo de potenciar las capacidades de aprendizaje automático en la detección de estructuras ocultas en los datos.
 * Además, futuras investigaciones podrían explorar otros métodos de reducción de dimensionalidad que preserven mejor la 
 * información relevante sin comprometer el ajuste del modelo.
 * */

namespace TripleVariable {
    internal class Ecuacion {
        private Nodo Arbol;
        public List<Registro> Registros;
        public List<Registro> Test;

        // Constructor
        public Ecuacion() {
            Registros = [];
            Test = [];
        }

        // Obtiene la ecuación en forma de texto
        public string ImprimeEcuacion() {
            return "Z = " + ObtenerEcuacion(Arbol);
        }

        //Genera una ecuación al azar para generar los datos
        public void CreaDatos(Random Azar, int Profundidad, int NumRegistros) {
            double MinimoZ = 0, MaximoZ = 0, Acumula = 0;
            double valX, valY, valZ;

            bool Aceptable = true;
            Registros.Clear();
            Test.Clear();

            do {

                //Crea el árbol binario
                Aceptable = true;
                Arbol = GenerarArbol(Azar, Profundidad);

                //Valida si la ecuación generada tiene en cuenta las variables
                //independientes
                for (int prueba=1; prueba<=100; prueba++) {

                    //Valida si la variable X impacta en el resultado
                    valX = Azar.NextDouble();
                    valY = Azar.NextDouble();
                    double valZ1 = EvaluaArbol(Arbol, valX, valY);

                    if (double.IsNaN(valZ1) || double.IsInfinity(valZ1)) {
                        Aceptable = false;
                        break;
                    }

                    valX = Azar.NextDouble();
                    double valZ2 = EvaluaArbol(Arbol, valX, valY);

                    if (double.IsNaN(valZ2) || double.IsInfinity(valZ2) || Math.Abs(valZ1 - valZ2) <= 0.001) {
                        Aceptable = false;
                        break;
                    }

                    //Valida si la variable Y impacta en el resultado
                    valX = Azar.NextDouble();
                    valY = Azar.NextDouble();
                    valZ1 = EvaluaArbol(Arbol, valX, valY);

                    if (double.IsNaN(valZ1) || double.IsInfinity(valZ1)) {
                        Aceptable = false;
                        break;
                    }

                    valY = Azar.NextDouble();
                    double valZ3 = EvaluaArbol(Arbol, valX, valY);

                    if (double.IsNaN(valZ3) || double.IsInfinity(valZ3) || Math.Abs(valZ1 - valZ3) <= 0.001) {
                        Aceptable = false;
                        break;
                    }
                }

                //Genera los registros
                if (Aceptable) {
                    Registros.Clear();

                    MinimoZ = double.MaxValue;
                    MaximoZ = double.MinValue;
                    Acumula = 0;
                    for (int NuevoReg = 0; NuevoReg < NumRegistros; NuevoReg++) {
                        valX = Azar.NextDouble();
                        valY = Azar.NextDouble();
                        valZ = EvaluaArbol(Arbol, valX, valY);

                        if (double.IsNaN(valZ) || double.IsInfinity(valZ)) {
                            Aceptable = false;
                            break;
                        }

                        Acumula += valZ;
                        if (valZ < MinimoZ) MinimoZ = valZ;
                        if (valZ > MaximoZ) MaximoZ = valZ;
                        Registros.Add(new Registro(valX, valY, valZ));
                    }
                }

                //Evalúa los registros con el promedio. Si alguno está muy
                //por encima del promedio o muy abajo del promedio, entonces
                //se rechazan esos datos
                if (Aceptable) {
                    double Promedio = Acumula / Registros.Count;

                    for (int Reg = 0; Reg < Registros.Count; Reg++)
                        if (Registros[Reg].ValorZ < Promedio * 0.1 ||
                            Registros[Reg].ValorZ > Promedio * 3) {
                            Aceptable = false;
                            break;
                        }
                }

            } while (Aceptable == false);

            //Normaliza los datos de salida
            for (int Reg = 0; Reg < Registros.Count; Reg++)
                Registros[Reg].ValorZ = (Registros[Reg].ValorZ - MinimoZ) / (MaximoZ - MinimoZ);

            //Extrae el 10% al azar para usarlo como datos para probar el modelo (no se usan para entrenamiento)
            int Extrae = Registros.Count / 10;
            Test.Clear();
            for (int Reg = 1; Reg <= Extrae; Reg++) {
                int Pos = Azar.Next(Registros.Count);
                Test.Add(new Registro(Registros[Pos].ValorX, Registros[Pos].ValorY, Registros[Pos].ValorZ));
                Registros.RemoveAt(Pos);
            }
        }

        //Pone un nodo manteniendo el árbol binario equilibrado
        private Nodo GenerarArbol(Random Azar, int Profundidad) {
            if (Profundidad == 0) return null;

            Nodo nodo = new(Azar) {
                Izquierda = GenerarArbol(Azar, Profundidad - 1),
                Derecha = GenerarArbol(Azar, Profundidad - 1)
            };
            return nodo;
        }

        //  Recorrido en Post-Orden para evaluar el árbol binario
        private double EvaluaArbol(Nodo Arbol, double valX, double valY) {
            //No hay nodos hijos, entonces
            //es un número o una variable
            if (Arbol.Izquierda == null)
                if (Arbol.VarX)
                    return valX;
                else if (Arbol.VarY) 
                    return valY;
                else
                    return Arbol.Numero;

            //Recorrido Post-Orden
            double ValIzquierda = EvaluaArbol(Arbol.Izquierda, valX, valY);
            double ValDerecha = EvaluaArbol(Arbol.Derecha, valX, valY);

            //Aplica operador
            double Valor = 0;
            switch (Arbol.Operador) {
                case '+': Valor = ValIzquierda + ValDerecha; break;
                case '-': Valor = ValIzquierda - ValDerecha; break;
                default: Valor = ValIzquierda * ValDerecha; break;
            }

            // Código de la función 0:seno, 1:coseno, 2:tangente,
			// 3: valor absoluto, 4: raiz cuadrada del valor absoluto, -1 no es función
            switch (Arbol.Funcion) {
                case 0: return Math.Sin(Valor);
                case 1: return Math.Cos(Valor);
                case 2: return Math.Abs(Valor);
                case 3: return Math.Sqrt(Math.Abs(Valor));
            }
            return Valor;
        }

        //  Recorrido en Post-Orden para obtener la ecuación
        private string ObtenerEcuacion(Nodo Arbol) {
            //No hay nodos hijos, entonces
            //es un número o una variable
            if (Arbol.Izquierda == null)
                if (Arbol.VarX) {
                    return "X";
                }
                else if (Arbol.VarY) {
                    return "Y";
                }
                else
                    return Math.Round(Arbol.Numero, 2).ToString();

            //Recorrido Post-Orden
            string ValIzquierda = ObtenerEcuacion(Arbol.Izquierda);
            string ValDerecha = ObtenerEcuacion(Arbol.Derecha);

            //Aplica operador
            string Valor = "";
            switch (Arbol.Operador) {
                case '+': Valor = "(" + ValIzquierda + "+" + ValDerecha + ")"; break;
                case '-': Valor = "(" + ValIzquierda + "-" + ValDerecha + ")"; break;
                default: Valor = "(" + ValIzquierda + "*" + ValDerecha + ")"; break;
            }

            /* Código de la función 0:seno, 1:coseno,
			 * 2: valor absoluto, 3: raiz cuadrada del valor absoluto
			 * -1 no es función */
            switch (Arbol.Funcion) {
                case 0: return "seno" + Valor;
                case 1: return "cos" + Valor;
                case 2: return "abs" + Valor;
                case 3: return "raiz(abs" + Valor + ")";
            }
            return Valor;
        }

        // Imprime los registros en formato CSV
        public void ImprimeRegistros() {
            for (int Cont = 0; Cont < Registros.Count; Cont++) { 
                Console.Write(Registros[Cont].ValorX + ";");
                Console.Write(Registros[Cont].ValorY + ";");
                Console.WriteLine(Registros[Cont].ValorZ + ";");
            }
        }

    }
}
