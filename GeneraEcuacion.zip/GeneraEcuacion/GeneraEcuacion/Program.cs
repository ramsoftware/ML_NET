﻿/*
Comparativa entre la librería ML .NET (Machine Learning) y MathNet.Numerics (Estadística)
en ajuste de curvas e interpolación en una serie de datos tipo Y = F(X)

Abstract
This paper presents a comparative analysis of two libraries, ML .NET and MathNet.Numerics,
in the context of curve fitting and interpolation for datasets of the form Y=F(X).
The study aims to evaluate the accuracy, and interpolation of both libraries
through a series of experiments on synthetic data. Key metrics such as mean squared
error (MSE), computational efficiency, and ease of implementation are used to assess
the strengths and weaknesses of each library.

Resumen
Este artículo presenta un análisis comparativo de dos librerías, ML .NET y MathNet.Numerics,
en el contexto del ajuste de curvas e interpolación para conjuntos de datos de la forma Y=F(X).
El estudio tiene como objetivo evaluar la precisión y la interpolación de ambas
librerías a través de una serie de experimentos con datos sintéticos. Se utilizan métricas clave
como el error cuadrático medio (MSE), la eficiencia computacional y la facilidad de implementación
para evaluar las fortalezas y debilidades de cada librería.
 
Autor: Rafael Alberto Moreno Parra
GitHub: https://github.com/ramsoftware 
Fecha: Febrero de 2025
 * */

using MathNet.Numerics;
using MathNet.Numerics.LinearAlgebra;

using Microsoft.ML;
using Microsoft.ML.Trainers.FastTree;

namespace GeneraEcuacion {
    internal class Program {
        static Ecuacion Datos = new();

        static void Main() {
            int MejorNumerics = 0, MejorML = 0;

            Console.WriteLine("Prueba;Math-Numerics(MSE);ML.NET(MSE)");
            for (int Cont = 1; Cont <= 1000; Cont++) {
                GeneraDatos();
                double MSENumerics = UsaNumerics();
                double MSEML = UsaML();
                if (MSENumerics < MSEML) MejorNumerics++;
                if (MSEML < MSENumerics) MejorML++;
                Console.WriteLine(Cont + ";" + MSENumerics + ";" + MSEML);
            }
            Console.WriteLine("\r\nCONCLUSIÓN:");
            Console.WriteLine("Gana Math.Numerics: " + MejorNumerics);
            Console.WriteLine("Gana ML .NET con FastTree: " + MejorML);
        }

        static void GeneraDatos() {
            //Profundidad del árbol binario
            int Profundidad = 5;

            //Cuantos registros va a crear
            int NumRegistros = 3000;

            //Crea la ecuación
            Datos.CreaEcuacion(Profundidad, NumRegistros);
        }

        // Función modelo personalizada a*seno(b*x+c) + ..... + p*seno(q*x+r)
        static double Modelo(double X, Vector<double> Parametros) {
            double Resultado = 0;
            for (int Cont = 0; Cont < Parametros.Count; Cont += 3)
                Resultado += Parametros[Cont] * Math.Sin(Parametros[Cont + 1] * X + Parametros[Cont + 2]);
            return Resultado;
        }

        // Función de error (suma de los cuadrados de los errores)
        static double FuncionError(Vector<double> Parametros) {
            double Error = 0;
            for (int Cont = 0; Cont < Datos.Registros.Count; Cont++) {
                double Ypredice = Modelo(Datos.Registros[Cont].ValorX, Parametros);
                Error += (Datos.Registros[Cont].ValorY - Ypredice) * (Datos.Registros[Cont].ValorY - Ypredice);
            }
            return Error;
        }

        //Uso de la librería Math.Numerics
        static double UsaNumerics() {
            // Valores iniciales para los parámetros
            int NumSumasSeno = 5;
            double[] ArregloParametros = new double[NumSumasSeno*3];
            for (int Cont = 0; Cont < ArregloParametros.Length; Cont++)
                ArregloParametros[Cont] = 0.5;
            
            var ValorInicial = Vector<double>.Build.DenseOfArray(ArregloParametros);

            /* AJUSTAR LA CURVA
             * El parámetro tolerance en los algoritmos de optimización como los de MathNet.Numerics
             * define la precisión deseada para la solución. Este parámetro controla cuánto pueden
             * variar las soluciones sucesivas antes de que el algoritmo decida que ha alcanzado
             * un resultado suficientemente bueno y se detenga.
             * 
             * En otras palabras, tolerance especifica la cantidad máxima de error permitida en
             * la solución final. Una tolerancia más pequeña significa que se requiere una solución
             * más precisa, lo que puede llevar a más iteraciones y mayor tiempo de cálculo.
             * Por otro lado, una tolerancia más grande permite soluciones menos precisas y puede
             * resultar en una convergencia más rápida.
             * 
             * La diferencia entre 0.01 y 0.001 es el nivel de precisión:
             * 0.01: Esta tolerancia es más relajada y permite un error mayor en la solución final.
             *       El algoritmo puede detenerse más rápidamente, pero la solución puede ser
             *       menos precisa.
             *       
             * 0.001: Esta tolerancia es más estricta, lo que significa que el algoritmo buscará
             * una solución con un error mucho menor. Puede llevar más tiempo y más iteraciones
             * alcanzar esta precisión, pero la solución será más exacta.
            */

            var Resultado = FindMinimum.OfFunction(
                function: FuncionError,
                initialGuess: ValorInicial,
                tolerance: 0.001, // Ajusta la tolerancia según sea necesario
                maxIterations: 6000 // Incrementa el número máximo de iteraciones
            );

            //Compara los valores Test con la curva hallada
            double Acumula = 0;
            for (int Cont = 0; Cont < Datos.Test.Count; Cont++) {
                double x = Datos.Test[Cont].ValorX;
                double y = Modelo(x, Resultado);
                double Diferencia = Datos.Test[Cont].ValorY - y;
                Acumula += Diferencia * Diferencia;
            }
            return Acumula;
        }

        //Uso de la librería ML .NET
        static double UsaML() {
            //Los datos XY
            List<Dato> DatosEvalua = [];
            for (int registro = 0; registro < Program.Datos.Registros.Count; registro++) {
                float Xval = (float)Program.Datos.Registros[registro].ValorX;
                float Yval = (float)Program.Datos.Registros[registro].ValorY;
                DatosEvalua.Add(new Dato { X = Xval, Y = Yval });
            }

            var ContextoML = new MLContext();
            var Datos = ContextoML.Data.LoadFromEnumerable(DatosEvalua);

            // Dividir los datos en entrenamiento y testeo
            var PreparaDatos = ContextoML.Data.TrainTestSplit(Datos, testFraction: 0.2);
            var DatosEntrenamiento = PreparaDatos.TrainSet;
            var DatosTesteo = PreparaDatos.TestSet;

            // Definir el pipeline de entrenamiento (aprendizaje) con
            // normalización y ajuste de parámetros.
            //Fue necesario instalar el paquete Microsoft.ML.FastTree
            var Aprendizaje = ContextoML.Transforms.Concatenate("Caracteristicas", "X")
                .Append(ContextoML.Transforms.NormalizeMinMax("Caracteristicas"))
                .Append(ContextoML.Regression.Trainers.FastTree(new FastTreeRegressionTrainer.Options {
                    NumberOfLeaves = 50, // Ajusta según sea necesario
                    MinimumExampleCountPerLeaf = 5, // Ajusta según sea necesario
                    LearningRate = 0.1, // Ajusta según sea necesario
                    NumberOfTrees = 200, // Ajusta según sea necesario
                    LabelColumnName = "Y",
                    FeatureColumnName = "Caracteristicas"
                }));

            // Entrenar el modelo
            var ModeloEntrenado = Aprendizaje.Fit(DatosEntrenamiento);

            // Hacer transformaciones
            ModeloEntrenado.Transform(DatosTesteo);

            // Crear un motor de predicción
            var MotorPrediccion = ContextoML.Model.CreatePredictionEngine<Dato, ModeloPrediccion>(ModeloEntrenado);

            //Datos no usados en el entrenamiento
            List<Dato> DatosProbar = [];
            for (int registro = 0; registro < Program.Datos.Test.Count; registro++) {
                float Xval = (float)Program.Datos.Test[registro].ValorX;
                float Yval = (float)Program.Datos.Test[registro].ValorY;
                DatosProbar.Add(new Dato { X = Xval, Y = Yval });
            }

            //Compara con los datos de testeo
            var DatosTest = ContextoML.Data.LoadFromEnumerable(DatosProbar);
            var DatosEnum = ContextoML.Data.CreateEnumerable<Dato>(DatosTest, reuseRowObject: false).ToList();

            double Acumula = 0;
            for (int i = 0; i < DatosEnum.Count; i++) {
                var Fila = DatosEnum[i];
                var predice = MotorPrediccion.Predict(new Dato { X = Fila.X });
                double Diferencia = Program.Datos.Test[i].ValorY - predice.Y;
                Acumula += Diferencia * Diferencia;
            }
            return Acumula;
        }

    }
}