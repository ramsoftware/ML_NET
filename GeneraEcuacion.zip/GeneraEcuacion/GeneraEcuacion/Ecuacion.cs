﻿/*
Comparativa entre la librería ML .NET (Machine Learning) y MathNet.Numerics (Estadística)
en ajuste de curvas e interpolación en una serie de datos tipo Y = F(X)

Abstract
This paper presents a comparative analysis of two libraries, ML .NET and MathNet.Numerics,
in the context of curve fitting and interpolation for datasets of the form Y=F(X).
The study aims to evaluate the accuracy, and interpolation of both libraries
through a series of experiments on synthetic data. Key metrics such as mean squared
error (MSE), computational efficiency, and ease of implementation are used to assess
the strengths and weaknesses of each library.

Resumen
Este artículo presenta un análisis comparativo de dos librerías, ML .NET y MathNet.Numerics,
en el contexto del ajuste de curvas e interpolación para conjuntos de datos de la forma Y=F(X).
El estudio tiene como objetivo evaluar la precisión y la interpolación de ambas
librerías a través de una serie de experimentos con datos sintéticos. Se utilizan métricas clave
como el error cuadrático medio (MSE), la eficiencia computacional y la facilidad de implementación
para evaluar las fortalezas y debilidades de cada librería.
 
Autor: Rafael Alberto Moreno Parra
GitHub: https://github.com/ramsoftware 
Fecha: Febrero de 2025
 * */
namespace GeneraEcuacion {

    //Crea la ecuación al azar y luego
    //el lote de registros de entradas y salida
    //que genera la ecuación
    internal class Ecuacion {
        private Random Azar;
        private Nodo Arbol;
        public List<Registro> Registros;
        public List<Registro> Test;

        /* Constructor */
        public Ecuacion() {
            Registros = new List<Registro>();
            Test = new List<Registro>();
            Azar = new Random();
        }

        /* La variable X que es la causal */
        private double valX;

        /* Obtiene la ecuación en forma de texto */
        public string Imprime() {
            return "Y = " + ObtenerEcuacion(Arbol);
        }

        public void CreaEcuacion(int Profundidad, int NumRegistros) {
            double Minimo = 0, Maximo = 0;
            bool Aceptable = true;
            Registros.Clear();
            Test.Clear();

            do {

                //Crea el árbol binario
                Aceptable = true;
                Arbol = GenerarArbol(Profundidad);

                //Primero el valor de X en forma creciente
                double[] ValoresX = new double[NumRegistros];
                ValoresX[0] = Azar.NextDouble();
                for (int NuevoReg = 1; NuevoReg < NumRegistros; NuevoReg++) {
                    ValoresX[NuevoReg] += Azar.NextDouble() + ValoresX[NuevoReg - 1];
                }

                //Normaliza esos valores de X
                Minimo = ValoresX[0];
                Maximo = ValoresX[NumRegistros - 1];
                for (int NuevoReg = 0; NuevoReg < NumRegistros; NuevoReg++) {
                    ValoresX[NuevoReg] = (ValoresX[NuevoReg] - Minimo) / (Maximo - Minimo);
                }

                //Genera los registros
                Registros.Clear();

                Minimo = double.MaxValue;
                Maximo = double.MinValue;
                for (int NuevoReg = 0; NuevoReg < NumRegistros; NuevoReg++) {
                    valX = ValoresX[NuevoReg];
                    double Y = EvaluaArbol(Arbol);
                    if (double.IsNaN(Y) || double.IsInfinity(Y)) {
                        Aceptable = false;
                        break;
                    }
                    if (Y < Minimo) Minimo = Y;
                    if (Y > Maximo) Maximo = Y;
                    Registros.Add(new Registro(valX, Y));
                }

                //Evalúa los registros con el promedio. Si alguno está muy
                //por encima del promedio o muy abajo del promedio, entonces
                //se rechazan esos datos
                if (Aceptable) {
                    double Acumula = 0;
                    for (int Reg = 0; Reg < Registros.Count; Reg++)
                        Acumula += Registros[Reg].ValorY;
                    double Promedio = Acumula / Registros.Count;

                    for (int Reg = 0; Reg < Registros.Count; Reg++)
                        if (Registros[Reg].ValorY < Promedio * 0.3 || 
                            Registros[Reg].ValorY > Promedio * 1.7) {
                            Aceptable = false; break;
                        }
                }

                //Evalúa que no sea una simple línea creciente o decreciente.
                //Que tenga valles y picos
                if (Aceptable) {
                    int Picos = 0, Valles = 0;
                    for (int Reg = 0; Reg < Registros.Count - 2; Reg++) {
                        double valA = Registros[Reg].ValorY;
                        double valB = Registros[Reg + 1].ValorY;
                        double valC = Registros[Reg + 2].ValorY;

                        if (valA < valB && valB > valC) Picos++;
                        if (valA > valB && valB < valC) Valles++;
                    }
                    if (Picos < 3 || Valles < 3) Aceptable = false;
                    if (Picos > 50 || Valles > 50) Aceptable = false;
                }

            } while (Aceptable == false);

            //Normaliza los datos de salida
            for (int Reg = 0; Reg < Registros.Count; Reg++)
                Registros[Reg].ValorY = (Registros[Reg].ValorY - Minimo) / (Maximo - Minimo);

            //Extrae el 10% al azar para usarlo como datos para probar el modelo (no se usan para entrenamiento)
            int Extrae = Registros.Count / 10;
            Test.Clear();
            for (int Reg = 1; Reg <= Extrae; Reg++) {
                int Pos = Azar.Next(Registros.Count);
                Test.Add(new Registro(Registros[Pos].ValorX, Registros[Pos].ValorY));
                Registros.RemoveAt(Pos);
            }
        }

        //Pone un nodo manteniendo el árbol binario equilibrado
        private Nodo GenerarArbol(int Profundidad) {
            if (Profundidad == 0) return null;

            Nodo nodo = new Nodo(Azar);
            nodo.Izquierda = GenerarArbol(Profundidad - 1);
            nodo.Derecha = GenerarArbol(Profundidad - 1);
            return nodo;
        }

        /*  Recorrido en Post-Orden para 
			evaluar el árbol binario */
        private double EvaluaArbol(Nodo Arbol) {
            //No hay nodos hijos, entonces
            //es un número o una variable
            if (Arbol.Izquierda == null)
                if (Arbol.VarX)
                    return valX;
                else
                    return Arbol.Numero;

            //Recorrido Post-Orden
            double ValIzquierda = EvaluaArbol(Arbol.Izquierda);
            double ValDerecha = EvaluaArbol(Arbol.Derecha);

            //Aplica operador
            double Valor = 0;
            switch (Arbol.Operador) {
                case '+': Valor = ValIzquierda + ValDerecha; break;
                case '-': Valor = ValIzquierda - ValDerecha; break;
                case '*': Valor = ValIzquierda * ValDerecha; break;
                default: Valor = ValIzquierda / ValDerecha; break;
            };

            /* Código de la función 0:seno, 1:coseno, 2:tangente,
			 * 3: valor absoluto, 4: raiz cuadrada del valor absoluto, -1 no es función */
            switch (Arbol.Funcion) {
                case 0: return Math.Sin(Valor);
                case 1: return Math.Cos(Valor);
                case 2: return Math.Tan(Valor);
                case 3: return Math.Abs(Valor);
                case 4: return Math.Sqrt(Math.Abs(Valor));
            }
            return Valor;
        }

        /*  Recorrido en Post-Orden para 
            obtener la ecuación */
        private string ObtenerEcuacion(Nodo Arbol) {
            //No hay nodos hijos, entonces
            //es un número o una variable
            if (Arbol.Izquierda == null)
                if (Arbol.VarX) {
                    return "X";
                }
                else
                    return Arbol.Numero.ToString();

            //Recorrido Post-Orden
            string ValIzquierda = ObtenerEcuacion(Arbol.Izquierda);
            string ValDerecha = ObtenerEcuacion(Arbol.Derecha);

            //Aplica operador
            string Valor = "";
            switch (Arbol.Operador) {
                case '+': Valor = "(" + ValIzquierda + "+" + ValDerecha + ")"; break;
                case '-': Valor = "(" + ValIzquierda + "-" + ValDerecha + ")"; break;
                case '*': Valor = "(" + ValIzquierda + "*" + ValDerecha + ")"; break;
                default: Valor = "(" + ValIzquierda + "/" + ValDerecha + ")"; break;
            };

            /* Código de la función 0:seno, 1:coseno, 2:tangente,
			 * 3: valor absoluto, 4: raiz cuadrada del valor absoluto
			 * -1 no es función */
            switch (Arbol.Funcion) {
                case 0: return "seno" + Valor;
                case 1: return "cos" + Valor;
                case 2: return "tan" + Valor;
                case 3: return "abs" + Valor;
                case 4: return "raiz(abs" + Valor + ")";
            }
            return Valor;
        }
    }
}