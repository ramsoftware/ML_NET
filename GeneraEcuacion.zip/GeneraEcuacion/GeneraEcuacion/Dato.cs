﻿/*
Comparativa entre la librería ML .NET (Machine Learning) y MathNet.Numerics (Estadística)
en ajuste de curvas e interpolación en una serie de datos tipo Y = F(X)

Abstract
This paper presents a comparative analysis of two libraries, ML .NET and MathNet.Numerics,
in the context of curve fitting and interpolation for datasets of the form Y=F(X).
The study aims to evaluate the accuracy, and interpolation of both libraries
through a series of experiments on synthetic data. Key metrics such as mean squared
error (MSE), computational efficiency, and ease of implementation are used to assess
the strengths and weaknesses of each library.

Resumen
Este artículo presenta un análisis comparativo de dos librerías, ML .NET y MathNet.Numerics,
en el contexto del ajuste de curvas e interpolación para conjuntos de datos de la forma Y=F(X).
El estudio tiene como objetivo evaluar la precisión y la interpolación de ambas
librerías a través de una serie de experimentos con datos sintéticos. Se utilizan métricas clave
como el error cuadrático medio (MSE), la eficiencia computacional y la facilidad de implementación
para evaluar las fortalezas y debilidades de cada librería.
 
Autor: Rafael Alberto Moreno Parra
GitHub: https://github.com/ramsoftware 
Fecha: Febrero de 2025
 * */
namespace GeneraEcuacion
{
    class Dato
    {
        //Maneja 1 dato de entrada y 1 de salida
        public float X { get; set; }

        public float Y { get; set; }
    }
}
